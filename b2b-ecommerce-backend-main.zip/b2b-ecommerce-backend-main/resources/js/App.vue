<template>
  <router-view />
</template>

<script setup>
// Layout-urile sunt gestionate la nivel de router prin rute părinte
</script>

<style>
body {
  background-color: #f5f5f7;
}
</style>
