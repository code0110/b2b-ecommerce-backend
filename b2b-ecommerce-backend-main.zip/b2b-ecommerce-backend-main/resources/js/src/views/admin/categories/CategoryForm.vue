<template>
  <div class="container">
    <PageHeader title="Categorie - formular" subtitle="Formular categorie cu atribute, imagine și bannere.">
      <!-- Slot pentru butoane de acțiune (ex: Adaugă, Export etc.) -->
    </PageHeader>

    <div class="card shadow-sm">
      <div class="card-body">
        <p class="text-muted">
          Aceasta este o pagină de template pentru <strong>Categorie - formular</strong>.
          Completează cu tabele, formulare și componente specifice proiectului tău.
        </p>
        <ul class="small text-muted">
          <li>Respectă structura și câmpurile din specificația funcțională.</li>
          <li>Leagă această pagină de API-ul backend / ERP / procesator plăți.</li>
          <li>Extinde componentele Bootstrap sau creează componente personalizate.</li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script setup>
import PageHeader from '@/components/common/PageHeader.vue'
</script>
